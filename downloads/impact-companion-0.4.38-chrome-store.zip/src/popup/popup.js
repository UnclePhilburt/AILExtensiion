import { client, accessToken } from '../shared/auth-runtime.js';
import { parseBridgeUrl } from '../shared/bridge-config.js';
import { STORAGE_KEYS } from '../shared/storage-keys.js';
import { cloudEnabled, cloudState, isOnline, PHONE_URL } from '../shared/cloud-sync.js';
import { scriptStatusText } from '../background/salebase-scripts.js';
import { CLOSED_MESSAGE, callingHoursOpen } from '../shared/work-hours.js';
import { phoneRecovery } from '../shared/phone-recovery.js';
const $ = selector => document.querySelector(selector);
let session = null;
let checking = false;
let busy = false;
function say(message, error = false) { $('#message').textContent = message; $('#message').classList.toggle('error', error); }
function renderListener(listening, error = '') {
  $('#objectionListening').checked = Boolean(listening);
  $('#listenerHint').textContent = error || (listening
    ? 'Listening locally for saved objection phrases. No audio is saved.'
    : 'Off — it never listens unless you turn this on.');
}
const OBJECTION_STATUS = {
  looking: 'Matched — looking for the Salebase script window…',
  opened: 'Opened in your Salebase script window.',
  'no-script-window': 'Stopped at: finding the script window. No Salebase script window is open.',
  'page-not-reachable': 'Stopped at: talking to the Salebase page. Reload the Salebase tab and try again.',
  'page-error': 'Stopped at: opening the panel. The Salebase page script failed.',
  'rebuttal-not-found': 'Stopped at: finding the panel. That rebuttal was not found on the Salebase page.',
  'other-script': 'Not in the selected script — the easy-read view shows it from another script.',
  'not-in-script': 'The selected script has no rebuttal for this.',
  error: 'Stopped at: opening the rebuttal. Something went wrong.'
};
const time = (at) => (at ? new Date(at).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', second: '2-digit' }) : '');
function renderObjection(last, heard) {
  const status = $('#objectionStatus');
  const lines = [];
  if (last?.label) {
    const detail = last.status === 'opened' && last.message ? last.message : (OBJECTION_STATUS[last.status] || last.message || '');
    lines.push(`Last objection (${time(last.at)}): “${last.label}” — ${detail}`);
  }
  if (heard?.at && (!last?.at || heard.at > last.at + 1000)) {
    const outcome = heard.outcome === 'cooldown' ? `heard “${heard.label}” again, ignored for a few seconds`
      : heard.outcome === 'matcher-error' ? 'the matcher failed' : 'no objection matched';
    lines.push(`Last speech (${time(heard.at)}): ${outcome}.`);
  }
  if (!lines.length) { status.hidden = true; return; }
  status.textContent = lines.join(' ');
  status.classList.toggle('error', Boolean(last?.label) && !['opened', 'looking', 'other-script'].includes(last.status));
  status.hidden = false;
}
async function refreshListener() {
  const local = await chrome.storage.local.get(['impact.objectionListening', 'impact.objectionListenerError', 'impact.lastObjection', 'impact.lastHeard']);
  renderListener(local['impact.objectionListening'], local['impact.objectionListenerError']);
  renderObjection(local['impact.lastObjection'], local['impact.lastHeard']);
}
async function languageSettingsUrl() {
  if (globalThis.navigator?.brave && await globalThis.navigator.brave.isBrave()) return 'brave://settings/languages';
  const agent = navigator.userAgent;
  if (/Edg\//.test(agent)) return 'edge://settings/languages';
  if (/Chrome\//.test(agent)) return 'chrome://settings/languages';
  return null;
}
async function microphoneSettingsUrl() {
  if (globalThis.navigator?.brave && await globalThis.navigator.brave.isBrave()) return 'brave://settings/content/microphone';
  const agent = navigator.userAgent;
  if (/Edg\//.test(agent)) return 'edge://settings/content/microphone';
  if (/Chrome\//.test(agent)) return 'chrome://settings/content/microphone';
  return null;
}
async function requestMicrophone() {
  if (!navigator.mediaDevices?.getUserMedia) throw new Error('This browser cannot request microphone access.');
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  for (const track of stream.getTracks()) track.stop();
}
function renderSession(next) {
  session = next;
  $('#loading').hidden = true;
  $('#login').hidden = Boolean(next);
  $('#dashboard').hidden = !next;
  $('#accountEmail').textContent = next?.user?.email || '';
  if (next) { void refreshStatus(); void refreshListener(); }
}
async function accountPage() { await chrome.tabs.create({url:chrome.runtime.getURL('src/account/account.html')}); window.close(); }
$('#manageLogin').addEventListener('click', accountPage);
$('#manageAccount').addEventListener('click', accountPage);
$('#openPhone').addEventListener('click', () => chrome.tabs.create({url:PHONE_URL}));
$('#openOptions').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({active:true,currentWindow:true});
  if (tab?.id) await chrome.storage.session.set({'impact.debugTabId':tab.id});
  await chrome.runtime.openOptionsPage();
});
$('#refreshStatus').addEventListener('click', () => void refreshStatus());
$('#loginForm').addEventListener('submit', async event => {
  event.preventDefault();
  $('#signIn').disabled = true; say('Signing in…');
  try {
    if (!callingHoursOpen()) throw new Error(CLOSED_MESSAGE);
    const {data,error} = await client.auth.signInWithPassword({email:$('#email').value.trim(),password:$('#password').value});
    $('#password').value = '';
    if (error) throw error;
    renderSession(data.session); say('');
  } catch (error) { say(error.message,true); }
  finally { $('#signIn').disabled = false; }
});
client.auth.onAuthStateChange((_event,next) => renderSession(next));
chrome.storage.onChanged.addListener(changes => {
  if (changes['impact.supabase.session']) void client.auth.getSession().then(({data})=>renderSession(data.session));
  if (changes['impact.objectionListening'] || changes['impact.objectionListenerError'] || changes['impact.lastObjection'] || changes['impact.lastHeard']) void refreshListener();
});
$('#objectionListening').addEventListener('change', async (event) => {
  const enabled = event.target.checked;
  event.target.disabled = true;
  renderListener(enabled, enabled ? 'Starting local listening…' : 'Turning listening off…');
  try {
    if (enabled) await requestMicrophone();
    const result = await chrome.runtime.sendMessage({ type: 'impact/setObjectionListening', enabled });
    if (!result?.ok) throw new Error(result?.error || 'Could not change listening.');
    renderListener(result.listening);
  } catch (error) {
    renderListener(false, error.message || 'Could not start local listening.');
  } finally { event.target.disabled = false; }
});
// Salebase script personalisation (on unless turned off).
chrome.storage.local.get('impact.fillScript').then((stored) => { $('#fillScript').checked = stored['impact.fillScript'] !== false; });
// Which Salebase script the current lead got (or why none), e.g. "Script: Response Card (matched)".
function renderScriptStatus(entry) {
  const line = $('#scriptStatus');
  line.textContent = scriptStatusText(entry);
  line.hidden = !line.textContent;
  line.classList.toggle('warn', Boolean(entry?.status) && !['selected', 'already-selected', 'no-script-window'].includes(entry.status));
}
chrome.storage.session.get('impact.scriptSelect').then((stored) => renderScriptStatus(stored['impact.scriptSelect'])).catch(() => {});
chrome.storage.onChanged.addListener((changes, area) => { if (area === 'session' && changes['impact.scriptSelect']) renderScriptStatus(changes['impact.scriptSelect'].newValue); });
// Easy-read script view over the Salebase page (on unless turned off; applies live).
chrome.storage.local.get('impact.calmScripts').then((stored) => { $('#calmScripts').checked = stored['impact.calmScripts'] !== false; });
$('#calmScripts').addEventListener('change', (event) => {
  void chrome.storage.local.set({ 'impact.calmScripts': event.target.checked });
  say(event.target.checked ? 'The Salebase script now uses the easy-read view.' : 'The Salebase script shows as the original page.');
});
$('#fillScript').addEventListener('change', (event) => {
  void chrome.storage.local.set({ 'impact.fillScript': event.target.checked });
  say(event.target.checked ? 'Lead details will show in the Salebase script.' : 'The Salebase script shows its original placeholders.');
});
$('#reopenPhoneScripts').addEventListener('click', async () => {
  const button = $('#reopenPhoneScripts');
  button.disabled = true;
  say('Opening new phone script windows…');
  try {
    const result = await chrome.runtime.sendMessage({ type: 'impact/reopenPhoneScripts' });
    if (!result?.ok) throw new Error(result?.error || 'Could not reopen the phone script.');
    say(result.lanes.length === 2 ? 'Opened new Phone 1 and Phone 2 script windows.' : 'Opened a new Phone 1 script window.');
  } catch (error) { say(error.message, true); }
  finally { button.disabled = false; }
});
for (const [id, slot] of [['#openPhone1Script', '1'], ['#openPhone2Script', '2']]) {
  $(id).addEventListener('click', async () => {
    const button = $(id); button.disabled = true;
    try {
      const result = await chrome.runtime.sendMessage({ type: 'impact/openPhoneScriptWindow', slot });
      if (!result?.ok) throw new Error(result?.error || `Could not open the Phone ${slot} script.`);
      say(`Opened a new Phone ${slot} script window.`);
    } catch (error) { say(error.message, true); }
    finally { button.disabled = false; }
  });
}
$('#requestMicrophone').addEventListener('click', async () => {
  await chrome.tabs.create({ url: chrome.runtime.getURL('src/offscreen/microphone-permission.html') });
  window.close();
});
$('#openMicrophoneSettings').addEventListener('click', async () => {
  const url = await microphoneSettingsUrl();
  if (!url) { say('Open your browser microphone settings and allow IMPACT Companion.', true); return; }
  await chrome.tabs.create({ url });
});
$('#installEnglishPack').addEventListener('click', async () => {
  const button = $('#installEnglishPack');
  button.disabled = true; say('Downloading the local English voice pack…');
  try {
    // Chrome requires install() to be called from the actual button gesture.
    // Passing it through the service worker or an offscreen document removes
    // that activation and makes Chrome reject the request.
    const Recognition = globalThis.SpeechRecognition || globalThis.webkitSpeechRecognition;
    if (!Recognition || typeof Recognition.install !== 'function') throw new Error('This browser cannot install an on-device English speech pack.');
    const install = Recognition.install({ langs: ['en-US'], processLocally: true });
    const installed = await install;
    if (!installed) throw new Error('The English voice pack could not be installed.');
    say('English voice pack installed. Turn listening on.');
  } catch (error) { say(error.message, true); }
  finally { button.disabled = false; }
});
$('#openLanguageSettings').addEventListener('click', async () => {
  const url = await languageSettingsUrl();
  if (!url) { say('Open your browser language settings and add English voice support.', true); return; }
  await chrome.tabs.create({ url });
});
async function refreshStatus() {
  if (!session || checking) return;
  checking = true;
  const accountId = session.user.id;
  try {
    const [active] = await chrome.tabs.query({active:true,currentWindow:true});
    const onImpact = Boolean(active?.url?.startsWith('https://mobile.impact.ailife.com/Lead/'));
    $('#impactState').textContent = onImpact ? 'Open and ready' : 'Select an IMPACT tab';
    const useCloud = await cloudEnabled();
    $('#connectionLabel').textContent = useCloud ? 'Cloud connection' : 'Computer bridge';
    $('#phoneSetup').hidden = !useCloud;
    let status;
    if (useCloud) {
      const state = await cloudState();
      const local = await chrome.storage.local.get('impact.deviceId');
      if (isOnline(state?.desktop_seen) && state.device_id !== local['impact.deviceId']) throw new Error('Another computer is connected. Close IMPACT there and wait 45 seconds.');
      status = {phoneConnected:isOnline(state?.phone_seen),updatedAt:state?.lead_updated_at, state};
    } else {
    const settings = await chrome.storage.local.get([STORAGE_KEYS.bridgeUrl,STORAGE_KEYS.bridgeToken]);
    const bridgeUrl = parseBridgeUrl(settings[STORAGE_KEYS.bridgeUrl]);
    if (!settings[STORAGE_KEYS.bridgeToken]) throw new Error('Set up the bridge connection in Options.');
    const response = await fetch(`${bridgeUrl}/api/status`, {headers:{Authorization:`Bearer ${await accessToken()}`,'x-bridge-token':settings[STORAGE_KEYS.bridgeToken]},signal:AbortSignal.timeout(10000)});
    status = await response.json();
    if (!response.ok) throw new Error(status.error || 'The bridge did not respond.');
    }
    if (session?.user.id !== accountId) return;
    $('#bridgeState').textContent = 'Connected';
    $('#lastUpdate').textContent = status.updatedAt ? new Date(status.updatedAt).toLocaleTimeString([], {hour:'numeric',minute:'2-digit'}) : 'No updates yet';
    const connected = status.phoneConnected && onImpact;
    $('#connectionCard').dataset.state = connected ? 'connected' : 'checking';
    $('#connectionTitle').textContent = connected ? 'Connected' : 'Almost ready';
    $('#connectionHint').textContent = !onImpact ? 'Select your IMPACT lead tab to use the phone controls.' : !status.phoneConnected ? 'Open the phone page and sign in with this account.' : 'Your computer and phone are ready to work together.';
    $('#updatePhone').disabled = !onImpact || busy;
    renderPhoneLanes(status.state, useCloud, status.phoneConnected);
  } catch (error) {
    $('#bridgeState').textContent = 'Not connected'; $('#lastUpdate').textContent = '—';
    $('#connectionCard').dataset.state = 'offline'; $('#connectionTitle').textContent = 'Connection needed';
    $('#connectionHint').textContent = error.name==='TimeoutError' || error instanceof TypeError ? 'Cannot reach your connection. Check your internet and connection settings.' : error.message;
    $('#updatePhone').disabled = true;
    renderPhoneLanes(null, true, false);
  } finally { checking = false; }
}
function renderPhoneLanes(state, useCloud, phoneConnected) {
  const lanes = $('#phoneLanes');
  lanes.replaceChildren();
  const recovery = useCloud
    ? ['1', '2'].map(slot => phoneRecovery(state, slot))
    : ['1'].map(slot => ({ id: slot, connected: phoneConnected, state: phoneConnected ? 'connected' : 'reconnect', message: phoneConnected ? 'Connected' : 'Reconnect phone', lead: null }));
  let needsReconnect = false;
  for (const lane of recovery) {
    const row = document.createElement('article'); row.className = 'phoneLane'; row.dataset.state = lane.state;
    const number = document.createElement('span'); number.className = 'laneNumber'; number.textContent = lane.id;
    const copy = document.createElement('div'); copy.className = 'laneCopy';
    const title = document.createElement('strong'); title.textContent = `Phone ${lane.id}`;
    const detail = document.createElement('span'); detail.textContent = lane.lead?.leadName ? `Lead waiting: ${lane.lead.leadName}` : lane.connected ? 'Ready for its assigned IMPACT window' : 'No phone heartbeat received';
    copy.append(title, detail);
    const stateLabel = document.createElement('span'); stateLabel.className = 'laneState'; stateLabel.textContent = lane.message;
    row.append(number, copy, stateLabel); lanes.append(row);
    needsReconnect ||= lane.state === 'reconnect';
  }
  const hint = $('#recoveryHint');
  hint.hidden = !needsReconnect;
  hint.textContent = needsReconnect ? 'The assigned lead stays safely in its lane for 30 minutes. Reconnect the named phone, then select its matching Phone 1 or Phone 2 setting.' : '';
  $('#phoneSetup').hidden = !needsReconnect;
  $('#overallPill').textContent = needsReconnect ? 'Needs attention' : phoneConnected ? 'Ready' : 'Checking';
}
$('#updatePhone').addEventListener('click', async () => {
  if (busy) return;
  busy=true; $('#updatePhone').disabled=true; say('Syncing your phone…');
  try {
    const [tab] = await chrome.tabs.query({active:true,currentWindow:true});
    if (!tab?.url?.startsWith('https://mobile.impact.ailife.com/Lead/')) throw new Error('Open your IMPACT lead tab first.');
    await chrome.scripting.executeScript({target:{tabId:tab.id},files:['src/content/selector-config.js','src/content/impact-diagnostic.js']});
    const result = await withTimeout(chrome.tabs.sendMessage(tab.id,{type:'impact/getSnapshot',includeNextLead:false}),10000);
    if (!result?.ok) throw new Error(result?.error || 'Could not read IMPACT.');
    const sent = await withTimeout(chrome.runtime.sendMessage({type:'impact/publishLead',lead:result.snapshot.localLeadPreview}),12000);
    if (!sent?.ok) throw new Error(sent?.error || 'Could not sync the phone.');
    say('Phone synced.');
  } catch (error) { say(error.message,true); }
  finally { busy=false; void refreshStatus(); }
});
function withTimeout(promise, ms) { let timer; return Promise.race([promise,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('The request timed out. Refresh IMPACT and try again.')),ms);})]).finally(()=>clearTimeout(timer)); }
setInterval(refreshStatus,5000);
